function Statistics_ttest2( MDdataPath,CondataPath ,OutPath,name,number)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% number��������ϡ���
%class��ʾ����larger,smaller,emport
 MDreadlist=dir(strcat(MDdataPath,'\*.mat'));
 [MDm MDn]=size(MDreadlist);
 Conreadlist=dir(strcat(CondataPath,'\*.mat'));
[Conm Conn]=size(Conreadlist);
%readlist=dir(strcat(MDdataPath,'\*.mat'));
%[m n]=size(readlist);
%h = waitbar(0,'Please wait...');
%for NodeNum=1:90
for NodeNum=1:MDm 
 %CONfilename=strcat('oneDegrees',num2str(NodeNum),'.mat')
 %MDfilename=strcat('oneDegrees',num2str(NodeNum),'.mat')
 ConfileName=Conreadlist(NodeNum,1).name;
 MDfilename =MDreadlist(NodeNum,1).name;
 MDmatPath=strcat(MDdataPath,'\',MDfilename)
 ConmatPath=strcat(CondataPath,'\',ConfileName);
 MDmat=importdata(MDmatPath);
 Conmat=importdata(ConmatPath);
 for PNum=1:number
 MDa=MDmat(PNum,:);
 Cona=Conmat(PNum,:);
 %MDa=MDmat(1,:);
 %Cona=Conmat(1,:);
 %[p,h] = ranksum(MDa,Cona)
%[h,p] = kstest2(MDa,Cona)

%[h,p] = kstest2(MDa,Cona); 
 [H,P,CI,STATS]=ttest(MDa,Cona);
 Statis_T(PNum,NodeNum)=STATS.tstat;
 Statis_P(PNum,NodeNum)=P;
 end
%waitbar(NodeNum/MDm,h,'Please wait...',h); 
end 
save(strcat(OutPath,'\',name,'_T'),'Statis_T');
save(strcat(OutPath,'\',name,'_P'),'Statis_P');
%close(h);
end

